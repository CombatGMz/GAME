# DDoS Tool (Layer 4 and Layer 7)

## Installation

1. Clone the repository or copy the files into your VPS:
   ```bash
   git clone <repo-url>
   cd DDoS-Tool